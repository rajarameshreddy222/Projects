package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Dao;
import model.Employee;
@WebServlet(urlPatterns = {"/reqreg","/reqviewallusers","/reqsearch","/updatefrom","/reqUpdate","/reqdelete"})
public class Controller extends HttpServlet
{

public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
{PrintWriter out=res.getWriter();
	String path=req.getServletPath();
	if(path.equals("/reqviewallusers"))
	   {
		ArrayList<Employee> al=new ArrayList<Employee>();
		
		al=(ArrayList<Employee>)new Dao().viewAllEmployees();
		req.setAttribute("employee", al);
		RequestDispatcher rd=req.getRequestDispatcher("viewEmployee.jsp");
        rd.forward(req, res);
        }
	     if(path.equals("/updatefrom"))
			{ Employee e=new Employee();
			  e.setEmail(req.getParameter("id"));
			  e=new Dao().viewbyid(e);
			  req.setAttribute("employee", e);
			  RequestDispatcher rd=req.getRequestDispatcher("updateFrom.jsp");
			  rd.forward(req,res);
		
			}
	     if(path.equals("/reqUpdate"))
	 	{ boolean b=false;
	 		Employee e=new Employee();
	 		e.setEmail(req.getParameter("t1"));
	 		e.setName(req.getParameter("t2"));
	 		e.setGender(req.getParameter("t3"));
	 		e.setMobile(req.getParameter("t4"));
	 		e.setCity(req.getParameter("t5"));
	 		b=new Dao().update(e);
	 		RequestDispatcher rd=req.getRequestDispatcher("reqviewallusers");
	         rd.forward(req, res);
	 		
	 	/*	ArrayList<Employee> al=new ArrayList<Employee>();
	 		al=(ArrayList<Employee>)new Dao().viewAllEmployees();
			req.setAttribute("employee", al);
	 		if(b) {
	 		RequestDispatcher rd=req.getRequestDispatcher("viewEmployee.jsp");
	         rd.forward(req, res);*/
	 	}
	 	if(path.equals("/reqdelete"))
	 	{boolean b=false;
 		Employee e=new Employee();
 		e.setEmail(req.getParameter("id"));
 		b=new Dao().deleteemployee(e);
 		RequestDispatcher rd=req.getRequestDispatcher("reqviewallusers");
        rd.forward(req, res);
 		
	 		
	 	}

	
}

public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
{   PrintWriter out=res.getWriter();
	String path=req.getServletPath();
	if(path.equals("/reqreg"))
	{boolean b=false;
		Employee e=new Employee();
		e.setEmail(req.getParameter("t1"));
		e.setName(req.getParameter("t2"));
		e.setGender(req.getParameter("t3"));
		e.setMobile(req.getParameter("t4"));
		e.setCity(req.getParameter("t5"));
		b=new Dao().insert(e);
		if(b)
		{
			 RequestDispatcher rd=req.getRequestDispatcher("index.jsp");
             rd.include(req, res);
             out.print("<center> <b>Record inserted successfully");	
		}
	}
	if(path.equals("/reqsearch"))
	{
		Employee e=new Employee();
		e.setEmail(req.getParameter("t1"));
		e=new Dao().viewbyid(e);
		req.setAttribute("employee", e);
		RequestDispatcher rd=req.getRequestDispatcher("employeeSearch.jsp");
        rd.forward(req, res);
		
	}
	}

}

package dao;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import model.Employee;

public class Dao 
{
	
	SessionFactory sf=null;
	public Dao()
	{
		Configuration  cfg=new Configuration().configure().addAnnotatedClass(Employee.class);
		sf=cfg.buildSessionFactory();
		
	}
	
	public boolean insert(Employee e)
	{boolean b=false;
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		Object obj=session.save(e);
		if(obj!=null)
				{
			     b=true;
				}
		tx.commit();
		session.close();
		return b;
	}
	
	public ArrayList<Employee> viewAllEmployees()
	{   Session session=sf.openSession();
		ArrayList<Employee> al=new ArrayList<Employee>();
		al=(ArrayList<Employee>)session.createQuery("from Employee_hibernateweb").list();
		return al;
	}
	
	public Employee viewbyid(Employee e)
	{ 
		
		Employee e1=new Employee();
		Session session=sf.openSession();
		e1=(Employee)session.get(Employee.class, e.getEmail());
		
		return e1;
		
	}
	public boolean deleteemployee(Employee e)
	{
		boolean b=false;
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		e=(Employee)session.get(Employee.class, e.getEmail());
		session.delete(e);
		b=true;
		tx.commit();
		session.close();
		return b;
	}

	public boolean update(Employee e) {
		boolean b=false;
		Session session=sf.openSession();
		Transaction tx=session.beginTransaction();
		session.update(e);
		b=true;
		tx.commit();
		session.close();
		
		return b;
	}
	

}

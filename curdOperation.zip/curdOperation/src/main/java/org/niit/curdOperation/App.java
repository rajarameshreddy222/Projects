package org.niit.curdOperation;


import java.util.ArrayList;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.niit.curdOperation.model.Employee;

public class App 
{
    public static void main( String[] args )
    {int  opt;
       
        
        
        
        Configuration cfg=new Configuration().configure().addAnnotatedClass(Employee.class);
        SessionFactory sf=cfg.buildSessionFactory();
        Session session=sf.openSession();
        Transaction t=session.beginTransaction();
    	Scanner s=new Scanner(System.in);
    	do {
    	System.out.println("\n 1.Insert");
    	System.out.println("2.View All");
    	System.out.println("3.Update");
    	System.out.println("4.Delete");
    	System.out.println("5.Search");
    	
    	System.out.println("Select options 1-5 ");
    	opt=s.nextInt();
    	if(opt==1)
    	{ Employee e=new Employee();
        System.out.println("Enter email");
        String email=s.next();
        e.setEmail(email);
        System.out.println("Enter name");
        String name=s.next();
    	e.setName(name);
    	System.out.println("Enter city");
    	 String city=s.next();
    	e.setCity(city);
    	System.out.println("Enter gender");
    	 String gender=s.next();
    	e.setGender(gender);
    	System.out.println("Enter mobile  ");
    	 String mobile=s.next();
    	e.setMobile(mobile);
    	session.save(e);
    	t.commit();
        }
    	else if(opt==2)
    	{ Employee e2=new Employee();
    		 ArrayList<Employee> al=new ArrayList<Employee>();
      	   al=(ArrayList<Employee>)session.createQuery("from Employee_hibernateCore").list();
      	   for(Employee e21:al)
      	   {
      		   System.out.println("\n"+e21.getName()+"  "+e21.getEmail()+"  "+e21.getGender()+"  "+e21.getMobile()+"  "+e21.getCity());
      	   }	
    	}
    	else if(opt==3)
    	{ 
    	
    		  Employee e3=new Employee();
    	        System.out.println("Enter name");
    	        String name=s.next();
    	    	e3.setName(name);
    	    	System.out.println("Enter city");
    	    	 String city=s.next();
    	    	e3.setCity(city);
    	    	System.out.println("Enter gender");
    	    	 String gender=s.next();
    	    	e3.setGender(gender);
    	    	System.out.println("Enter mobile  ");
    	    	 String mobile=s.next();
    	    	e3.setMobile(mobile);
    	    	
    	    	 System.out.println("Enter email");
     	        String email=s.next();
     	       e3.setEmail(email);
    	    	
     	        session.update(e3);
     	       t.commit();
    	    	
    	}
    	
    	
    	else if(opt==4)
    	{ Employee e4=new Employee();
    		System.out.println("Enter email");
    		e4.setEmail(s.next());
    	    session.delete(e4);
             t.commit();
    	}
    	
    	
    	
    	else if(opt==5)
    	{ 
    		Employee e5=new Employee();
    	System.out.println("Enter email");
        String email=s.next();
        e5=(Employee)session.get(Employee.class,email);
        
       System.out.println(e5.toString());
 
     }
    
    	
       
    }
    
    	
    while(opt!=0);	
      	
      	
    }
}

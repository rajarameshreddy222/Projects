package model;

public class Orders
{
	private int count;
	private double sumoftotal;
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public double getSumoftotal() {
		return sumoftotal;
	}
	public void setSumoftotal(double sumoftotal) {
		this.sumoftotal = sumoftotal;
	}
	
	

}

package dao;

import model.Product;

public interface Dao {

	boolean addProduct(Product p);

}

package niit.com.hibernate2;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import niit.com.hibernate2.model.Employee;
import niit.com.hibernate2.model.FullName;


public class App 
{
    public static void main( String[] args )
    {
        FullName f=new FullName();
        f.setFname("V.Raja");
        f.setMname("Ramesh");
        f.setLname("Reddy");
        Employee e=new Employee();
        e.setEmail("V@gmail.com");
        e.setName(f);
        e.setCity("Hyd");
        e.setGender("male");
        e.setMobile("7894561230");
        
        Configuration cfg=new Configuration().configure().addAnnotatedClass(Employee.class);
        
        SessionFactory sf=cfg.buildSessionFactory();
        
        Session session=sf.openSession();
        
       Transaction t=session.beginTransaction();
       
       session.save(e);
       t.commit();
       
        
    }
}
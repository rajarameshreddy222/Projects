package dao;



import java.sql.Connection;
import java.util.ArrayList;

import model.Admin;
import model.Bill;
import model.Customer;
import model.Employee;
import model.Product;
import model.Stock;

public interface Dao{
public boolean    customerlogin(Customer c);

public boolean    customerregister(Customer c);

public boolean    Update(Customer c);

public boolean    delete(String id);

public boolean    adminlogin(Admin a);

public boolean    employeelogin(Employee e);

public boolean    employeeregister(Employee c);

public boolean    delete(Employee c);

public boolean    update(Employee c);

public boolean    productadd(Product p);

public boolean    deleteproduct(Product p);

public boolean    updateproduct(Product p);

public Customer   viewUserDetailsById(String id);

public Employee   viewByuserId(String id);

public Product    viewById(int id);

public ArrayList<Customer> viewallcustomer( );

public ArrayList<Employee> viewallemployee( );

public ArrayList<Product> viewallproduct( );

public Product  prodviewById(int id);

public boolean bill(Bill bi);

public ArrayList<Product> searchbillById(Product p);

public ArrayList<Bill> viewKartlist(String name);

public boolean  requestStock(Stock s);

public ArrayList<Stock> viewstock (Stock s);


public boolean deletefromkart(Bill bi);









	
	


}




















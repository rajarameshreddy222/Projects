package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.Admin;
import model.Bill;
import model.Customer;
import model.Employee;
import model.Product;
import model.Stock;

public class DaoImple implements Dao
{  static Connection con=null;



public static Connection getConnectionObject() 
    {
	   try {
         
		  Class.forName("org.h2.Driver");
		  con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/MyProject2","sa","sa");
	      }
         catch(Exception e)
	     {
	     System.out.println(e);
	     }		
	     return con;	
    }

	
	public boolean customerlogin(Customer c)
	{
		{ boolean b=false;
		con=DaoImple.getConnectionObject();
		 try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select name ,pwd from cus where name='"+c.getName()+"'and pwd='"+c.getPwd()+"'");
			if(rs.next()) {
			b=true;
			
			}
		    } 
		 catch (SQLException e)
		   {
			System.out.println(e);
		   }
		 return b;	
		}
		
	}

	
	public boolean customerregister(Customer c)
	{   
		boolean b=false;
		con=DaoImple.getConnectionObject();
		try {
		  PreparedStatement	ps=con.prepareStatement("insert into cus values (?,?,?,?,?)");
			ps.setString(1,c.getName());
			ps.setString(2,c.getPwd());
			ps.setString(3,c.getEmail());
			ps.setLong(4,c.getMobile());
			ps.setString(5,c.getCity());
			int i=ps.executeUpdate();
			if(i>0)
			{
			b=true;
			}
			
		} catch (SQLException e) {
			System.out.println(e);
		}
	return b;
	}


	public boolean Update(Customer c)
	
	{
		boolean b=false;
		con=DaoImple.getConnectionObject();
		try {
		PreparedStatement	ps=con.prepareStatement("update cus set pwd='"+c.getPwd()+"',email='"+c.getEmail()+"',mobile='"+c.getMobile()+"',city='"+c.getCity()+"' where name='"+c.getName()+"'");
		int	i=ps.executeUpdate();
			if(i>0)
			{
				b=true;
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
		return b;
		}

	
	public boolean delete(String id)
	{ boolean b=false;
	
		
		con=DaoImple.getConnectionObject();
		try {
			Statement stmt=con.createStatement();
		int	rs=stmt.executeUpdate("delete cus where name='"+id+"'");
		if(rs>0)
		{
		b=true;
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return b;
}



	public boolean adminlogin(Admin a)
	{ boolean b=false;
	con=DaoImple.getConnectionObject();
	 try {
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from admin where name='"+a.getName()+"'and pwd='"+a.getPwd()+"'");
		if(rs.next()) {
		b=true;
		
		}
	    } 
	 catch (SQLException e)
	   {
		System.out.println(e);
	   }
	 return b;	
	}


	public boolean employeelogin(Employee e) {
		{ boolean b=false;
		con=DaoImple.getConnectionObject();
		 try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from emp where name='"+e.getName()+"'and pwd='"+e.getPwd()+"'");
			if(rs.next()) {
			b=true;
			
			}
		    } 
		 catch (Exception E)
		   {
			System.out.println(E);
		   }
		 return b;	
		}
	}

    public boolean employeeregister(Employee e) {
		boolean b=false;
		con=DaoImple.getConnectionObject();
		try {
		  PreparedStatement	ps=con.prepareStatement("insert into emp values (?,?,?,?,?)");
			ps.setString(1,e.getName());
			ps.setString(2,e.getPwd());
			ps.setString(3,e.getEmail());
			ps.setLong(4,e.getMobile());
			ps.setString(5,e.getCity());
			int i=ps.executeUpdate();
			if(i>0)
			{
			b=true;
			}
			
		} catch (SQLException E) {
			System.out.println(e);
		}
	return b;
	}


	public boolean delete(Employee e) {
      boolean b=false;
		
		con=DaoImple.getConnectionObject();
		try {
		  Statement	ps=con.createStatement();
				  int i=ps.executeUpdate("delete emp where name='"+e.getName()+"'");
			if(i>0)
			{
			b=true;
			}
			
		} catch (SQLException E) {
			System.out.println(E);
		}
	return b;
	}
    

	
	public boolean update(Employee e)
	{con=DaoImple.getConnectionObject();
		boolean b=false;
		try {
			  PreparedStatement	ps=con.prepareStatement("update emp set pwd='"+e.getPwd()+"',email='"+e.getEmail()+"',mobile='"+e.getMobile()+"',city='"+e.getCity()+"'where name='"+e.getName()+"'");
					  int i=ps.executeUpdate();
				if(i>0)
				{
				b=true;
				}
				
			} catch (SQLException E) {
				System.out.println(e);
			}

	   
		return b;
		
	}

	public Customer viewUserDetailsById(String id)
	{
	
		Customer c=new Customer();
		con=DaoImple.getConnectionObject();
		try {
			Statement stmt=con.createStatement();
		ResultSet	rs=stmt.executeQuery("select * from cus where name='"+id+"'");
		if(rs.next())
		{
			c.setName(rs.getString(1));
			c.setPwd(rs.getString(2));
			c.setEmail(rs.getString(3));
			c.setMobile(rs.getLong(4));
			c.setCity(rs.getString(5));
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return c;
}
	
	public ArrayList<Customer> viewallcustomer( )
	    {  ArrayList<Customer> al=new ArrayList<Customer>();
	    	
			con=DaoImple.getConnectionObject();
			try {
				Statement stmt=con.createStatement();
			ResultSet	rs=stmt.executeQuery("select name,email,mobile,city from cus");
			while(rs.next())
			{  
			   Customer c=new Customer();
				c.setName(rs.getString(1));
			//	c.setPwd(rs.getString(2));
				c.setEmail(rs.getString(2));
				c.setMobile(rs.getLong(3));
				c.setCity(rs.getString(4));
				al.add(c);
			}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return al;
	    }


	public ArrayList<Employee> viewallemployee() {
			ArrayList<Employee> al=new ArrayList<Employee>();
			
			 con=DaoImple.getConnectionObject();
			 try {
					Statement stmt=con.createStatement();
				ResultSet	rs=stmt.executeQuery("select  name,email,mobile,city  from emp ");
				while (rs.next())
				{ 
				 Employee e=new Employee();
					e.setName(rs.getString(1));
				//	e.setPwd(rs.getString(2));
					e.setEmail(rs.getString(2));
					e.setMobile(rs.getLong(3));
					e.setCity(rs.getString(4));
					al.add(e);
				}
				}
				catch(Exception E)
				{
					System.out.println(E);
				}
				return al;
		 }
		
	public Employee viewByuserId(String id) {
		Employee c=new Employee();
		con=DaoImple.getConnectionObject();
		 try {
				Statement st=con.createStatement();
				ResultSet rs=st.executeQuery("select * from emp where name='"+id+"'");
				
				if(rs.next())
				{
			     c.setName(rs.getString(1));
			     c.setPwd(rs.getString(2));
			     c.setEmail(rs.getString(3));
			     c.setMobile(rs.getLong(4));
			     c.setCity(rs.getString(5));
				
				}} 
			 catch (SQLException e)
			   {
				System.out.println(e);
			   }
		return c;
	}


	public boolean productadd(Product p)
	{
		con=DaoImple.getConnectionObject();
		boolean b=false;
		
		try {
		  PreparedStatement	ps=con.prepareStatement("insert into product values (?,?,?,?)");
			ps.setInt(1,p.getId());
		    ps.setString(2,p.getName());
		    ps.setDouble(3,p.getPrice());
		    ps.setInt(4,p.getQuantity());
			int i=ps.executeUpdate();
			if(i>0)
			{
			b=true;
			}
			
		} catch (SQLException e) {
			System.out.println(e);
		}
	return b;
	}


	public boolean deleteproduct(Product p) {
        boolean b=false;
		
		con=DaoImple.getConnectionObject();
		try {
		  Statement	ps=con.createStatement();
				  int i=ps.executeUpdate("delete product where id='"+p.getId()+"'");
			if(i>0)
			{
			b=true;
			
			}
			
		} catch (SQLException e) {
			System.out.println(e);
		}
	     return b;
	}



	public boolean updateproduct(Product p) {
		 boolean b=false;
	        con=DaoImple.getConnectionObject();
	       
	       try { Statement st=con.createStatement();
			int i=st.executeUpdate("update product set  name='"+p.getName()+"',price='"+p.getPrice()+"',quantity='"+p.getQuantity()+"' where id='"+p.getId()+"'");
		if(i>0) 
		{b=true;
	  }
	       } catch (SQLException e) {
			System.out.println(e);
		}
	        return b;
	}
	public ArrayList<Stock> viewstock (Stock s)
	{     con=DaoImple.getConnectionObject();
		  ArrayList<Stock> al=new ArrayList<Stock>();
		  try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from stock ");
			while(rs.next())
			{
				Stock s1=new Stock();
				s1.setId(rs.getInt(1));
				s1.setName(rs.getString(2));
				s1.setQuantity(rs.getInt(3));
				s1.setEname(rs.getString(4));
				al.add(s1);
			}
			
			
		} catch (SQLException e) {
			System.out.println(e);
		}
		  
		
		
		return al;
	}
	

	public boolean  requestStock(Stock s)
	{ con=DaoImple.getConnectionObject();
	   Employee e=new Employee();
		boolean b=false;
	    try {
		PreparedStatement ps=con.prepareStatement("insert into  stock values (?,?,?,?)");
		
		ps.setInt(1,s.getId());
		ps.setString(2,s.getName());
		ps.setInt(3,s.getQuantity() );
		ps.setString(4,s.getEname());
	    int i=ps.executeUpdate();
	    if(i>0)
	    {
	    b=true;
	    }
   
	 } catch (SQLException E)
	 {
		System.out.println(E);
	 }
	 
  return b;	
	}
	

	public Stock  selectstock(Stock s)
	{ con=DaoImple.getConnectionObject();
		
	Statement st;
	try {
		st = con.createStatement();
		ResultSet rs=st.executeQuery("select * from stock where ename='"+s.getEname()+"'");
		if(rs.next())
		{
		 s.setId(rs.getInt(1));
		 s.setName(rs.getString(2));
		 s.setQuantity(rs.getInt(3));
		 s.setEname(rs.getString(4));
		}
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
		
	return s;
	}
	

	public Product viewById(int id) {
		 con=DaoImple.getConnectionObject();
		Product p=new Product();
       try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from product where id='"+id+"'");
			while(rs.next())
			{
				
				p.setId(rs.getInt(1));
				p.setName(rs.getString(2));	
				p.setPrice(rs.getDouble(3));	
				p.setQuantity(rs.getInt(4));
				
			
			}
		} catch (SQLException e) {
			System.out.println(e);
		}        
       
       	return p;
	}
	
	
	public ArrayList<Product> viewallproduct() {
		con=DaoImple.getConnectionObject();
		ArrayList al1=new ArrayList();
   	try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from product");
			while(rs.next())
			{  
				Product p=new Product();
				
				p.setId(rs.getInt(1));
				p.setName(rs.getString(2));	
				p.setPrice(rs.getDouble(3));	
				p.setQuantity(rs.getInt(4));
				
				al1.add(p);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}
  return al1;
	}

	
	public ArrayList<Product> searchbillById(Product p) {
		 con=DaoImple.getConnectionObject();
		 ArrayList<Product> al=new ArrayList<Product>();
	
      try {
			Statement st=con.createStatement();                                                
		     
			ResultSet rs=st.executeQuery("select id,name,price  from product where name like '%"+p.getName()+"%' order by name");
			while(rs.next())                                   
			{ Product p1=new Product();
				p1.setId(rs.getInt(1));
				p1.setName(rs.getString(2));	
				p1.setPrice(rs.getDouble(3));	
                al.add(p1);
			}
		} catch (SQLException e) {
			System.out.println(e);
		}        
      
      	return al;
	}
  

	public Product  prodviewById(int id) {
		 con=DaoImple.getConnectionObject();
		Product p=new Product();
      try {
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select id,name,price from product where id='"+id+"'");
			while(rs.next())
			{
				
				p.setId(rs.getInt(1));
				p.setName(rs.getString(2));	
				p.setPrice(rs.getDouble(3));	
				
				
			
			}
		} catch (SQLException e) {
			System.out.println(e);
		}        
      
      	return p;
	}

	public boolean bill(Bill bi)
	{boolean b=false;
	con=DaoImple.getConnectionObject();
		
	try {
		PreparedStatement ps=con.prepareStatement("insert into bill values (?,?,?,?,?,?)");
		
		ps.setInt(1,bi.getP_id());
	    ps.setString(2,bi.getP_name());
	    ps.setDouble(3,bi.getP_price());
	    ps.setInt(4,bi.getP_quantity());
	    ps.setDouble(5,((bi.getP_price())*(bi.getP_quantity())));
	    ps.setString(6,bi.getC_name());
	    int i=ps.executeUpdate();
	    if(i>0)
	    {
            Product p=new Product();
	    	Statement st=con.createStatement();
	    
	    	ResultSet rs=st.executeQuery("select quantity from product where id='"+bi.getP_id()+"'");
	    	
	    	if(rs.next())
	    	{
	    	
	    		p.setQuantity(rs.getInt(1));
	    		
                int i1=st.executeUpdate("update product set quantity='"+((p.getQuantity())-(bi.getP_quantity()))+"' where id='"+bi.getP_id()+"'");
	    		if(i1>0)
	    		{
	    			b=true;
	    		}
	    	}
	    	
	    	
	    	
	    }
		
		
	} catch (SQLException e) {
		
		System.out.println(e);
	}
	
	
	return b;
	}
    
	
	

	public ArrayList<Bill> viewKartlist(String name) 
	
	{ Bill bi=new Bill();
		con=DaoImple.getConnectionObject();
		
		ArrayList<Bill> al=new  ArrayList<Bill>();
	try {
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select P_id,P_name,P_price,P_quantity,P_total  from bill where c_name='"+name+"' ");
		while(rs.next())
		{ Bill bi1=new Bill();
			bi1.setP_id(rs.getInt(1));
			bi1.setP_name(rs.getString(2));
			bi1.setP_price(rs.getDouble(3));
			bi1.setP_quantity(rs.getInt(4));
			bi1.setP_total(rs.getDouble(5));
		    al.add(bi1);
		    
		}

		ResultSet rs1=st.executeQuery("select sum(p_total)as total from bill where c_name='"+name+"'  ");
		if(rs.next())
		{  
		
			bi.setP_total(rs1.getDouble(1));
			
		}
		
		
	  } catch (SQLException e) {
		
		e.printStackTrace();
	}
	
	
		return al;
	}
   
	public boolean deletefromkart(Bill bi) 
    { Product p=new Product();
		con=DaoImple.getConnectionObject();
		boolean b=false;
    try {
		Statement st=con.createStatement();
	        ResultSet rs1=st.executeQuery("select quantity from product where id='"+bi.getP_id()+"' ");
	        
	       if(rs1.next()) 
	       {
	    	  p.setQuantity(rs1.getInt(1));
	    	   }
			ResultSet rs=st.executeQuery("Select p_quantity from bill where p_id='"+bi.getP_id()+"'  ");
	
			
			
			if(rs.next())
	    	{ 
	    	
	    		bi.setP_quantity(rs.getInt(1));
	    		
                int i1=st.executeUpdate("update product set quantity='"+((p.getQuantity())+(bi.getP_quantity()))+"' where id='"+bi.getP_id()+"'");
	    		if(i1>0)
	    		{
	    			int i=st.executeUpdate(" delete bill where p_id='"+bi.getP_id()+"' ");
	    			
	    			if(i>0)
	    			{
	    				b=true;
	    			}
	    		}	
			
		}}
		
	catch (SQLException e) {
		
		e.printStackTrace();
	}
    return b;	
    }
	

	public ArrayList<Bill> totalsales( ) 
	{ ArrayList<Bill> al=new ArrayList<Bill>();
		con=DaoImple.getConnectionObject();
		
    try {
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select c_name,sum(p_total)as total FROM BILL group by c_name order by c_name");
	   while(rs.next())
	   {  Bill bi=new Bill();
		   bi.setC_name(rs.getString(1));
		   bi.setP_total(rs.getDouble(2));
		  al.add(bi);
	   }
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
		
    return al;	
	}
	
	
	public boolean stockupdateproduct(Product p) {
		 boolean b=false;
	        con=DaoImple.getConnectionObject();
	       
	       try { Statement st=con.createStatement();
			int i=st.executeUpdate("update product set  name='"+p.getName()+"',price='"+p.getPrice()+"',quantity='"+p.getQuantity()+"' where id='"+p.getId()+"'");
		if(i>0) 
		{
		  int  i1=st.executeUpdate("delete stock  where id='"+p.getId()+"' ");
		  if(i>0) 
		  {
			  b=true;
		  }
		}
	       } catch (SQLException e) {
			System.out.println(e);
		}
	        return b;
	}
	
	public Bill generatebill(String id)
	{
		Bill bi=new Bill();
		
		con=DaoImple.getConnectionObject();
		
		try {
			Statement st=con.createStatement();
			
			ResultSet rs=st.executeQuery("select sum(p_total)as total from bill where c_name='"+id+"'  ");
			if(rs.next())
			{  
			
				bi.setP_total(rs.getDouble(1));
				int i=st.executeUpdate(" delete bill where c_name='"+id+"'  ");
				
			}
			
			
	      } 
		catch (SQLException e) {
			
			e.printStackTrace();
		}

		return bi;
		
	}
	
	
	
}



	



















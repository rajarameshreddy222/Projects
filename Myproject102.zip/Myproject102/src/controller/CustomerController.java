package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.DaoImple;
import model.Customer;
@WebServlet(urlPatterns= {"/reqcuslogin","/reqcusreg","/reqviewallcus2","/reqcusviewbyid","/reqcusupdate1","/reqcusdelete","/reqcusupdate2","/reqviewallcus","/reqcusupdate12","/reqcusupdate21","/reqcusforget"})

public class CustomerController extends HttpServlet
{
                       DaoImple obj;
	                   Customer c=new Customer(); 
             public void init() throws ServletException
		        {
			         super.init();
			         obj=new DaoImple();
		        }
             public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
             {     PrintWriter out=res.getWriter();
          	        String path=req.getServletPath();
          	   
          	      if(path.equals("/reqcuslogin"))
          	      {  boolean b=false;
               	 
          		           c.setName(req.getParameter("t1").toLowerCase());
          		           c.setPwd(req.getParameter("t2"));
          		     
          		           b=obj.customerlogin(c);
          		       if(b)
          		           {
          			           HttpSession session=req.getSession();
          			         session.setAttribute("name", c.getName());
          			         RequestDispatcher rd=req.getRequestDispatcher("customerhomepage.html");
          			            rd.forward(req, res);
          		            }
          		       else
          		            {
          			          RequestDispatcher rd=req.getRequestDispatcher("signin.html");
          				      rd.include(req, res);
          				      out.print("error");
          		            }	  
          		  }
          	  
          	      else if(path.equals("/reqcusreg"))
          	      {  boolean b=false;
               	 
          		      c.setName(req.getParameter("t1").toLowerCase());
          	          c.setPwd(req.getParameter("t2"));
          	          c.setEmail(req.getParameter("t3").toLowerCase());
          	          c.setMobile(Integer.parseInt(req.getParameter("t4")));
          	          c.setCity(req.getParameter("t5").toLowerCase());
          	          b=obj.customerregister(c);
          	          if(b)
          	            {
          		            RequestDispatcher rd=req.getRequestDispatcher("signup.html");
          		            rd.include(req, res); 
          		            out.print("done");
          	            }
          	           else
          	           {
          		            
          		           out.print("error");
          	           }
          	          
          	      }
          	    else if(path.equals("/reqcusforget")) 
        	    {
        	    c.setName(req.getParameter("t1"));
        	    c.setPwd(req.getParameter("t2"));
        	    	boolean b=obj.forget(c);
        	    	if(b)
        	    	{
        	    	 RequestDispatcher rd=req.getRequestDispatcher("signin.html");
        	   		   rd.forward(req, res);
        	    	}
        	    	else
        	    	{
        	    		out.print(" Something went wrong");
        	    	}
        	   }     
             
           }
           public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
        {    Customer c=new Customer();
          	 PrintWriter out=res.getWriter();
          	 String path=req.getServletPath(); 
          	 if(path.contentEquals("/reqcusviewbyid"))
          	     { 
          	       HttpSession session =req.getSession();
          	       String name=session.getAttribute("name").toString();
          		   c=obj.viewUserDetailsById(name);
          		   out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>Name</th><th>Password</th><th>Email</th><th>Mobile</th><th>City</th><th>Update</th></tr>");
          		   out.print("<tr><td>"+c.getName()+"</td><td>"+c.getPwd()+"</td><td>"+c.getEmail()+"</td><td>"+c.getMobile()+"</td><td>"+c.getCity()+"</td><td><a href=reqcusupdate1?id="+c.getName()+">Update</a></td>");                            
          		  
          		   out.print(" </table><h2> To go back   Press <a href=customerhomepage.html><b>Here</a></h2>  ");
          	     }
          	    
          	    else if (path.equals("/reqcusupdate1")) 
          	     {
          	  	    
          	  	     String name=req.getParameter("id");
          	  	     c= obj.viewUserDetailsById(name);
          	  	
          	  		 out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><form action=reqcusupdate2><tr><td>Name:</td><td><input type=text name=t1 readonly value="+c.getName()+"></td></tr>");
          	  		 out.print("<tr><td>Pwd:   </td><td>     <input     type=text   name=t2  value="+c.getPwd()+"></td></tr>");
          	  	     out.print("<tr><td>Email: </td><td>     <input     type=text   name=t3  value="+c.getEmail()+"></td></tr>");
          	  	     out.print("<tr><td>Mobile:</td><td>     <input     type=text   name=t4  value="+c.getMobile()+"></td></tr>");
          	  	     out.print("<tr><td>City:  </td><td>     <input     type=text   name=t5  value="+c.getCity()+"></td></tr>");
          	  	     out.print("<tr><td><input type=submit value=Update></td><td><input type=reset value=reset></td></tr></table></form></body>");
          	  		
          			
          	     }
          	     else if (path.equals("/reqcusupdate2"))
          	     { boolean b =false;
          	    
          	    	   c.setName(req.getParameter("t1").toLowerCase());
          	    	   c.setPwd(req.getParameter("t2"));
          	  	       c.setEmail(req.getParameter("t3").toLowerCase());
          	  	       c.setMobile(Integer.parseInt(req.getParameter("t4")));
          	  	       c.setCity(req.getParameter("t5").toLowerCase());
          	  	       b=obj.Update(c);
          	  		  if(b)
          			  {
          				RequestDispatcher rd=req.getRequestDispatcher("reqcusviewbyid");
          				rd.forward(req, res);
          				
          			  }
          			  else
          			  {
          				  RequestDispatcher rd=req.getRequestDispatcher("customer.html");
          					rd.include(req, res);
          					out.print("error");
          			  }
          	     }
          	    
          	    
          	     else if(path.equals("/reqcusdelete"))
          			{
          				String name=req.getParameter("id");
          				boolean b=obj.delete(name);
          				  if(b)
          				  {
          					RequestDispatcher rd=req.getRequestDispatcher("reqviewallcus");
          					rd.forward(req, res);
          					out.print("Delete done..........!");
          				  }
          				  else
          				  {
          					  
          						out.print("error");
          				  }
          				   
          	      }
          	     else if(path.equals("/reqviewallcus"))
          	     {
          	    	ArrayList<Customer> al=new ArrayList<Customer>();
          	    	al=obj.viewallcustomer();
          	    	 out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>Name</th><th>Email</th><th>Mobile</th><th>City</th><th>Update</th><th>Delete</th></tr>");
            		for(Customer c1:al) {
          	    	 out.print("<tr><td>"+c1.getName()+"</td><td>"+c1.getEmail()+"</td><td>"+c1.getMobile()+"</td><td>"+c1.getCity()+"</td><td><a href=reqcusupdate12?id="+c1.getName()+">Update</a></td><td><a href=reqcusdelete?id="+c1.getName()+">Delete</a></td>");                            
            		}
            		out.print(" </table><h2> To go back   Press <a href=employehomepage.html><b>Here</a></h2>  ");
          	    	
          	     }
          	  
          	   else if (path.equals("/reqcusupdate12")) 
        	     {
        	  	    
        	  	     String name=req.getParameter("id");
        	  	     c= obj.viewUserDetailsById(name);
        	  	
        	  		 out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><form action=reqcusupdate21><tr><td>Name:</td><td><input type=text name=t1 readonly value="+c.getName()+"></td></tr>");
        	  		 out.print("<tr><td>Pwd:   </td><td>     <input     type=text   name=t2  value="+c.getPwd()+"></td></tr>");
        	  	     out.print("<tr><td>Email: </td><td>     <input     type=text   name=t3  value="+c.getEmail()+"></td></tr>");
        	  	     out.print("<tr><td>Mobile:</td><td>     <input     type=text   name=t4  value="+c.getMobile()+"></td></tr>");
        	  	     out.print("<tr><td>City:  </td><td>     <input     type=text   name=t5  value="+c.getCity()+"></td></tr>");
        	  	     out.print("<tr><td><input type=submit value=Update></td><td><input type=reset value=reset></td></tr></table></form></body>");
        	  		
        			
        	     }
        	     else if (path.equals("/reqcusupdate21"))
        	     { boolean b =false;
        	    
        	    	   c.setName(req.getParameter("t1").toLowerCase());
        	    	   c.setPwd(req.getParameter("t2"));
        	  	       c.setEmail(req.getParameter("t3").toLowerCase());
        	  	       c.setMobile(Integer.parseInt(req.getParameter("t4")));
        	  	       c.setCity(req.getParameter("t5").toLowerCase());
        	  	       b=obj.Update(c);
        	  		  if(b)
        			  {
        				RequestDispatcher rd=req.getRequestDispatcher("reqviewallcus");
        				rd.forward(req, res);
        				
        			  }
        			  else
        			  {
        				  
        					out.print("<center><h2> error while Updateding");
        			  }
        	     }
        
        
        
        
            }
}
	
	
	
	
	
	
	
	
	
	
	
	


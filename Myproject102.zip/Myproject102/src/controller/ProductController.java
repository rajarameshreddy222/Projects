package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Dao;
import dao.DaoImple;
import model.Bill;
import model.Customer;
import model.Employee;
import model.Product;
import model.Stock;
@WebServlet(urlPatterns= {"/reqprodadd","/viewproduct","/viewproduct2","/requpdateprod1","/reqdeleteproduct1","/requpdateproduct1","/reqdeleteproduct","/requpdateproduct","/requpdateprod","/reqcusproductviewall","/selectproduct","/reqbill","/reqsearch","/reqstock","/reqviewstock","/reqviewkart","/reqdeletebill","/selectstock","/reqtotal","/requpdatstock","/updatestock","/genertebill","/reqsearch1","/myorders","/reqsales"})

public class ProductController
extends HttpServlet
{
                       DaoImple obj;
	                   Customer c=new Customer(); 
             public void init() throws ServletException
		        {
			         super.init();
			         obj=new DaoImple();
		        }

    public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
      {   PrintWriter out=res.getWriter();
	      String path=req.getServletPath();
	     
	     
	      
	      if (path.equals("/reqprodadd")) 
	       {  Product p=new Product();
	    	   boolean b=false;
	  		p.setId(Integer.parseInt(req.getParameter("t1")));
	  		p.setName(req.getParameter("t2").toLowerCase());
	  		p.setPrice(Double.parseDouble(req.getParameter("t3")));
	  		p.setQuantity(Integer.parseInt(req.getParameter("t4")));
	  		b=obj.productadd(p);
	  	  if(b)
		   {
			   RequestDispatcher rd=req.getRequestDispatcher("employehomepage.html");
			   rd.forward(req, res);
			  
		   }
	  	 else
		   {
			  
			   out.print("error");
		   }
      }  
	      
      }   
	     
	      
	      
	      public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
	      { 
	   	  
	   	   PrintWriter out=res.getWriter();
	       String path=req.getServletPath(); 
	       Product p=new Product(); 
	       Bill bi=new Bill();
	       Stock s=new Stock();
	        if(path.equals("/viewproduct"))
	       {
	    	   ArrayList<Product> al=new  ArrayList<Product>();
	    			   al=obj.viewallproduct();
	    	   out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>id</th><th>name</th><th>price</th><th>quantity</th><th>Update</th><th>Delete</th></tr>");
	    	  
	    	   for(Product u: al)
				{ 
	    		out.print("<tr><td>"+u.getId()+"</td><td>"+u.getName()+"</td><td>"+u.getPrice()+"</td><td>"+u.getQuantity()+"</td><td><a href=requpdateproduct?id="+u.getId()+">Update</a></td><td><a href=reqdeleteproduct?id="+u.getId()+">Delete</a></td></tr>");
					                                                                                                                                                                                                                                                                                                    
	            }
	    	   out.print(" </table><h2> To go back   Press <a href=employehomepage.html><b>Here</a></h2>  ");	
	 	         	   
   }
	        if(path.equals("/viewproduct2"))
		       {
		    	   ArrayList<Product> al=new  ArrayList<Product>();
		    			   al=obj.viewallproduct();
		    	   out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>id</th><th>name</th><th>price</th><th>quantity</th><th>Update</th><th>Delete</th></tr>");
		    	  
		    	   for(Product u: al)
					{ 
		    		out.print("<tr><td>"+u.getId()+"</td><td>"+u.getName()+"</td><td>"+u.getPrice()+"</td><td>"+u.getQuantity()+"</td><td><a href=requpdateproduct1?id="+u.getId()+">Update</a></td><td><a href=reqdeleteproduct1?id="+u.getId()+">Delete</a></td></tr>");
						                                                                                                                                                                                                                                                                                                    
		            }
		    	   out.print(" </table><h2> To go back   Press <a href=adminhomepage.html><b>Here</a></h2>  ");	
		 	  }
	        
	        else if(path.equals("/reqdeleteproduct1"))
		       {
		    	 
		    	   p.setId(Integer.parseInt(req.getParameter("id")));
		    	   boolean b=obj.deleteproduct(p);
		    	   if(b)
		    	   {
		    		   RequestDispatcher rd=req.getRequestDispatcher("viewproduct2");
		    		   rd.forward(req, res);
		    		   out.print(" delete done ");
		    	   }
		    	   else 
		    	   {
		    		   out.print("error");
		    	   }
		    	}
		       else if(path.equals("/requpdateproduct1"))
		       { 
		    	   
		            int id=Integer.parseInt(req.getParameter("id"));
		             p=obj.viewById(id);
		             out.print("<body bgcolor=CCFFFF><br><br><center><form action=requpdateprod1><table border=3 cellpadding=10><tr><td>PId</td><td><input type=text name=t1 readonly value="+p.getId()+"></td></tr>");
		    		 out.print("<tr><td>PName</td><td>     <input     type=text   name=t2  value="+p.getName()+"></td></tr>");
		    	     out.print("<tr><td>PPrice </td><td>     <input     type=text   name=t3  value="+p.getPrice()+"></td></tr>");
		    	     out.print("<tr><td>PQuantity</td><td>     <input     type=text   name=t4  value="+p.getQuantity()+"></td></tr>");
		    	     out.print("<tr><td><input type=submit value=Update></td><td><input type=reset value=reset></td></tr></table></form></body>");
		       }
		       else if(path.equals("/requpdateprod1"))
		       { 
		        boolean b=false;
		 		p.setId(Integer.parseInt(req.getParameter("t1")));
		 		p.setName(req.getParameter("t2").toLowerCase());
		 		p.setPrice(Double.parseDouble(req.getParameter("t3")));
		 		p.setQuantity(Integer.parseInt(req.getParameter("t4"))); 
		    	b=obj.updateproduct(p);
		    	if(b)
		    	{ 
		    		RequestDispatcher rd=req.getRequestDispatcher("viewproduct2");
				    rd.forward(req, res);
		    		
		    	}
		    	else
		    		
		    	{
		    		out.print(" Error occured");
		    	}
		        
		       }
	        
       else if(path.equals("/reqdeleteproduct"))
	       {
	    	 
	    	   p.setId(Integer.parseInt(req.getParameter("id")));
	    	   boolean b=obj.deleteproduct(p);
	    	   if(b)
	    	   {
	    		   RequestDispatcher rd=req.getRequestDispatcher("viewproduct");
	    		   rd.forward(req, res);
	    		   out.print(" delete done ");
	    	   }
	    	   else 
	    	   {
	    		   out.print("error");
	    	   }
	    	}
	       else if(path.equals("/requpdateproduct"))
	       { 
	    	   
	            int id=Integer.parseInt(req.getParameter("id"));
	             p=obj.viewById(id);
	             out.print("<body bgcolor=CCFFFF><br><br><center><form action=requpdateprod><table border=3 cellpadding=10><tr><td>PId</td><td><input type=text name=t1 readonly value="+p.getId()+"></td></tr>");
	    		 out.print("<tr><td>PName</td><td>     <input     type=text   name=t2  value="+p.getName()+"></td></tr>");
	    	     out.print("<tr><td>PPrice </td><td>     <input     type=text   name=t3  value="+p.getPrice()+"></td></tr>");
	    	     out.print("<tr><td>PQuantity</td><td>     <input     type=text   name=t4  value="+p.getQuantity()+"></td></tr>");
	    	     out.print("<tr><td><input type=submit value=Update></td><td><input type=reset value=reset></td></tr></table></form></body>");
	       }
	       else if(path.equals("/requpdateprod"))
	       { 
	        boolean b=false;
	 		p.setId(Integer.parseInt(req.getParameter("t1")));
	 		p.setName(req.getParameter("t2").toLowerCase());
	 		p.setPrice(Double.parseDouble(req.getParameter("t3")));
	 		p.setQuantity(Integer.parseInt(req.getParameter("t4"))); 
	    	b=obj.updateproduct(p);
	    	if(b)
	    	{ 
	    		RequestDispatcher rd=req.getRequestDispatcher("viewproduct");
			    rd.forward(req, res);
	    		
	    	}
	    	else
	    		
	    	{
	    		out.print(" Error occured");
	    	}
	        
	       }
	       else if(path.equals("/reqcusproductviewall"))
	       {
	    	   ArrayList<Product> al=new  ArrayList<Product>();
			   al=obj.viewallproduct();
	   out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>id</th><th>name</th><th>price</th><th>quantity</th><th>select</th></tr>");
	  
	   for(Product u: al)
		{
		   out.print("<tr><td>"+u.getId()+"</td><td>"+u.getName()+"</td><td>"+u.getPrice()+"</td><td>"+u.getQuantity()+"</td><td><a href=selectproduct?id="+u.getId()+">Select</a></td></tr>");
		}
       }
	       else if(path.equals("/selectproduct"))
	       {
	    	   
	             int id=Integer.parseInt(req.getParameter("id"));
	             p=obj.prodviewById(id);
	             HttpSession session =req.getSession();
        	     String name=session.getAttribute("name").toString();
    
	             out.print("<body bgcolor=CCFFFF><br><br><center><form action=reqbill><table border=3 cellpadding=10 ><tr><td>Prodcut id</td><td><input type=text name=t1 readonly value="+p.getId()+"></td></tr>");
	    		 out.print("<tr><td>Productname   </td><td>     <input     type=text   name=t2 readonly value="+p.getName()+"></td></tr>");
	    	     out.print("<tr><td>price </td><td>     <input     type=text   name=t3  readonly value="+p.getPrice()+"></td></tr>");
	    	     out.print("<tr><td>Quantity</td><td>     <input     type=text   name=t4   ></td></tr>");
	    	     out.print("<tr><td>Cname</td><td>     <input     type=text   name=t6  readonly value="+name+"></td></tr>");
	    	     out.print("<tr><td><input type=submit value=AddtoKart></td><td><input type=reset value=reset></td></tr></table></form></body>");
	      
	       }
	       else if(path.equals("/reqbill")) 
	       {
	    	  
	       	    	
	    	   boolean b=false;
	    
	    	bi.setP_id(Integer.parseInt(req.getParameter("t1")));
	  		bi.setP_name(req.getParameter("t2").toLowerCase());
	  		bi.setP_price(Double.parseDouble(req.getParameter("t3").trim()));
	  		bi.setP_quantity(Integer.parseInt(req.getParameter("t4").trim()));
	  		
	  		bi.setC_name(req.getParameter("t6"));
            b=obj.bill(bi);
	  	    

	    	bi.setP_id(Integer.parseInt(req.getParameter("t1")));
	  		bi.setP_name(req.getParameter("t2").toLowerCase());
	  		bi.setP_price(Double.parseDouble(req.getParameter("t3").trim()));
	  		bi.setP_quantity(Integer.parseInt(req.getParameter("t4").trim()));
	  		bi.setC_name(req.getParameter("t6"));
	  	    b=obj.bill2(bi);
	  	 
	  	  if(b)
		   {
			   RequestDispatcher rd=req.getRequestDispatcher("customerhomepage.html");
			   rd.forward(req, res);
			   out.print("add to your kart");
			  
		   }
	  	 else
		   {
			  
			   out.print("error");
		   }
	    	   
	       }
	       else if (path.equals("/reqsearch"))
	       {
	    	   ArrayList<Product> al=new ArrayList<Product>();
	    	 
	    	   p.setName(req.getParameter("t1").toLowerCase());
               al=obj.searchbillById(p);
               out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>Product id</th><th>Product Name</th><th>price</th><th>select</th></tr>");
              for(Product p1:al ) {
               out.print("<tr><td>"+p1.getId()+"</td><td>"+p1.getName()+"</td><td>"+p1.getPrice()+"</td><td><a href=selectproduct?id="+p1.getId()+">Select</a></td></tr>");
       	 }}
              else if (path.equals("/reqsearch1"))
   	       {
   	    	   ArrayList<Product> al=new ArrayList<Product>();
   	    	 
   	    	   p.setName(req.getParameter("t1").toLowerCase());
                  al=obj.searchbillById(p);
                  out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>Product id</th><th>Product Name</th><th>price</th></tr>");
                 for(Product p1:al ) {
                  out.print("<tr><td>"+p1.getId()+"</td><td>"+p1.getName()+"</td><td>"+p1.getPrice()+"</td></tr>");
          	 }
             out.print("</table> <h1> For shopping press <a href=signin.html>LogIn</a>  ");
   	       }
	        
	      
	       else if(path.equals("/reqstock"))
	       {  
	    	   HttpSession session =req.getSession();
	    	   String name=session.getAttribute("name").toString();
	    	   Stock b=obj.selectstock(s);
	    	  
				  out.print("<body bgcolor=CCFFFF><br><br><center><table border=3 cellpadding=10><form action=selectstock>  <tr><td>ProductID</td><td><input type=text  name=t1 ></td></tr>");
				  out.print("<tr><td>ProductName</td><td><input type=text  name=t2 ></td></tr>");
				  out.print("<tr><td>ProductQuantity</td><td><input type=text  name=t3 ></td></tr>");
				  out.print("<tr><td>Ename</td><td><input type=text  name=t4  readonly value="+name+"></td></tr>");
				  out.print("<tr><td><input type=submit value=select </td><td><input type=reset   value=reset></td></tr></table></form></boby>");
				  out.print(" </table><h2> To go back   Press <a href=employehomepage.html><b>Here</a></h2>  ");	
	       }
	        
	       else if(path.equals("/selectstock"))  
	       {
	    	   s.setId(Integer.parseInt(req.getParameter("t1")));
	    	   s.setName(req.getParameter("t2"));
	    	   s.setQuantity(Integer.parseInt(req.getParameter("t3")));
	    	   s.setEname(req.getParameter("t4"));
	    	  boolean b=obj.requestStock(s);
	    	   if(b)
	    	   {
	    		   RequestDispatcher rd=req.getRequestDispatcher("employehomepage.html");
	    		   rd.forward(req,res);
	    		   out.print("reqest done ");
	    	   }
	    	   
	       }
	       else if(path.equals("/requpdatstock"))
	       {
	    	   int id=Integer.parseInt(req.getParameter("id"));
	             p=obj.viewById(id);
	             out.print("<body bgcolor=CCFFFF><br><br><center><form action=updatestock><table border=3 cellpadding=10 ><tr><td>PId</td><td><input type=text name=t1 readonly value="+p.getId()+"></td></tr>");
	    		 out.print("<tr><td>PName</td><td>     <input     type=text   name=t2 readonly value="+p.getName()+"></td></tr>");
	    	     out.print("<tr><td>PPrice </td><td>     <input     type=text   name=t3  readonly value="+p.getPrice()+"></td></tr>");
	    	     out.print("<tr><td>PQuantity</td><td>     <input     type=text   name=t4  value="+p.getQuantity()+"></td></tr>");
	    	     out.print("<tr><td><input type=submit value=Update></td><td><input type=reset value=reset></td></tr></table></form></body>");
          }
	       else if(path.contentEquals("/updatestock")) 
	       {
	    	   boolean b=false;
		 		p.setId(Integer.parseInt(req.getParameter("t1")));
		 		p.setName(req.getParameter("t2").toLowerCase());
		 		p.setPrice(Double.parseDouble(req.getParameter("t3")));
		 		p.setQuantity(Integer.parseInt(req.getParameter("t4"))); 
		    	b=obj.stockupdateproduct(p);
		    	if(b)
		    	{ 
		    		RequestDispatcher rd=req.getRequestDispatcher("adminhomepage.html");
				    rd.forward(req, res);
		    		
		    	}
		    	else
		    		
		    	{
		    		out.print(" Error occured");
		    	}
	    	
	    	   
	    	   
	       }
	        
	       else if(path.equals("/reqviewstock"))
	       {
	    	   
	    	   ArrayList<Stock> al=new ArrayList<Stock>();
	    	   al=obj.viewstock(s);
	    	   out.print(" <body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>PId</th><th>PName</th><th>PQuantity</th><th>Empname</th><th>Update</th></tr>");
	    		  
	    	   for(Stock u:al)
	    		{
	    		   out.print("<tr><td>"+u.getId()+"</td><td>"+u.getName()+"</td><td>"+u.getQuantity()+"</td><td>"+u.getEname()+"</td><td><a href=requpdatstock?id="+u.getId()+"> update </a></td></tr>");
	    		}
	    	   out.print("</table><h1> To go back press<a href=adminhomepage.html><b>Menu</a> ");
	    	   
	    	   
	       }
	       else if(path.equals("/reqviewkart"))
	       {
	    	   ArrayList<Bill> al=new  ArrayList<Bill>();
	    	   
	 	      HttpSession session =req.getSession();
      	       String name=session.getAttribute("name").toString();
	    	   al=obj.viewKartlist(name);
	    	   
	    		
	    	   out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10><tr><th>pid</th><th>pname</th><th>pprice</th><th>pquantity</th><th>ptotal</th><th>odate</th><th>delete</th></tr>");
	    	  for(Bill bi1:al)
	    	  {
	    		  out.print("<tr><td>"+bi1.getP_id()+"</td><td>"+bi1.getP_name()+"</td><td>"+bi1.getP_price()+"</td><td>"+bi1.getP_quantity()+"</td><td>"+bi1.getP_total()+"</td><td>"+bi1.getDdate() +"</td><td><a href=reqdeletebill?id="+bi1	.getP_id()+"> delete  </a></td></tr>");
		      }
	    	 
	    	  Bill bi1=obj.generatebill(name);
	    	  
	    	  out.print("</table> <table  border=3 cellpadding=10> <tr><td><b>Total Bill Amount</td></tr> "); 
    		  
	    	  out.print("<tr><td><b>"+bi1.getP_total()+"</td> </table> ");
	    	  out.print("</table><h2> Press here to <a href=genertebill><b>GenerateBill</b></a> <br><br> </body>");
	    	  out.print(" <h2>Press here to go <a href=customerhomepage.html><b>Menu</b></a></h2>  ");
	       }
	        
	       else if(path.equals("/reqdeletebill")) 
	       { 
	    	   bi.setP_id(Integer.parseInt(req.getParameter("id")));
      	       boolean b=obj.deletefromkart(bi);
      	       if(b)
      	       {
      	    	   
      	    	  RequestDispatcher rd=req.getRequestDispatcher("reqviewkart");
      	    	   rd.forward(req, res);
      	    	  
      	       }
      	    
	       }
	       else if(path.equals("/reqtotal"))
	       {
	    	ArrayList<Bill> al=new ArrayList<Bill>();
	   		al=obj.totalsales();
	    	 out.print("<body bgcolor=CCFFFF><br><br><center><table  border=3 cellpadding=10> <tr><th><h1><b>c_name</th> <th><h1><b>total</th></tr>");  
	    	 for(Bill bi1:al)
	    	 {
	    		out.print("<tr><th><h1>"+bi1.getC_name()+"</h1></th><th><h1>"+bi1.getP_total()+"</h1></th>  ");
	    	 }
	    	 
	    	 
	    	 out.print("</table><h1> To go back press<a href=adminhomepage.html><b>Menu</a> ");
	       }
	       
	        
	        
	       else if(path.equals("/myorders"))
	       {
	    	   ArrayList<Bill> al=new  ArrayList<Bill>();
	    	   
	 	   HttpSession session =req.getSession();
      	       String name=session.getAttribute("name").toString();
	    	   al=obj.myorderlist(name);
	    	   
	    		
	    	   out.print("<body bgcolor=CCFFFF><br><br><center><h2> <b> Myorder histroy <br> <table  border=3 cellpadding=10><tr><th>pid</th><th>pname</th><th>pprice</th><th>pquantity</th><th>ptotal</th><th>odate</th></tr>");
	    	  for(Bill bi1:al)
	    	  {
	    		  out.print("<tr><td>"+bi1.getP_id()+"</td><td>"+bi1.getP_name()+"</td><td>"+bi1.getP_price()+"</td><td>"+bi1.getP_quantity()+"</td><td>"+bi1.getP_total()+"</td><td>"+bi1.getDdate()+"</td></tr>");
		      }
	    	 
	    	
	    	  out.print(" </table><h2>Press here to go <a href=customerhomepage.html><b>Menu</b></a></h2>  ");
	       }
	        
	   
	       else if(path.equals("/genertebill")) 
	       {
	    	  HttpSession session =req.getSession();
      	      String name=session.getAttribute("name").toString();
	    	   
	    	bi=obj.ddate(name);
	    	
	    	   
	    	   out.print("<body bgcolor=CCFFFF><br><br><center><table><tr><th> <h2> Bill Generated Successfully.It will delivery  <br>between"+bi.getDdate()+" and "+bi.getEdate()+".If you to <br>continue Press <a href=customerhomepage.html><b>Continue Shopping </a></h2> </th</tr></table> ");
	      }
	        
	       else if(path.equals("/reqsales"))
	       {  
	    	   
	    	    
	    	bi.setStartdate(req.getParameter("t1"));
	    	bi.setEndate(req.getParameter("t2"));
	    	   
	    	   ArrayList<Bill> al=new ArrayList<Bill>();
	    	   
	    	   
	    	   
	    	  al=obj.checksales(bi);
	    	    	  out.print("<body bgcolor=CCFFFF><br><br><center> <table border=1 cellpadding=10><tr><td>P_id</td><td>p_name</td><td>P_quantity</td><td>Totalsales</td></tr> ");
	    	 for(Bill bi1:al) {
	    	out.print("<tr><td>"+bi1.getP_id()+"</td><td>"+bi1.getP_name()+"</td><td>"+bi1.getP_quantity()+"</td><td>"+bi1.getP_total()+"</td></tr>  ");	 
	    	 }
	    	   
	       }
	        
	        
    
	}}	
	      
	      
	      
	      
	      
	      
	      



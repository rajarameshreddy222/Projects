package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.DaoImple;
import model.Customer;
import model.Employee;

@WebServlet(urlPatterns= {"/reqemplogin","/reqempreg","/reqempdelete","/reqempupdate","/requpdate1","/reqempview","/reqviewallemployee","/requpdate12","/reqempupdate1","/reqempforget"})                           
public class EmployeeController extends HttpServlet
{   DaoImple obj;

Customer c=new Customer(); 
	public void init() throws ServletException
	{
		super.init();
		obj=new DaoImple();
	
	}
     
public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
     { PrintWriter out=res.getWriter();
      String path=req.getServletPath();

     Employee e=new Employee();
    if(path.equals("/reqemplogin"))
    { boolean b=false;
	  e.setEmail(req.getParameter("t1").toLowerCase());
	  e.setPwd(req.getParameter("t2"));
	   b=obj.employeelogin(e);
	  if(b)
	  {
		 
		  HttpSession session=req.getSession();
		  session.setAttribute("name", e.getEmail());
		RequestDispatcher rd=req.getRequestDispatcher("employehomepage.html");
		rd.forward(req, res);
	  }
	  else
	  {
		  RequestDispatcher rd=req.getRequestDispatcher("signin.html");
			rd.include(req, res);
			out.print("error");
	  }	 }
	  else if(path.equals("/reqempreg"))
		 {  boolean b=false;
		   e.setName(req.getParameter("t1").toLowerCase());
		   e.setPwd(req.getParameter("t2"));
		   e.setEmail(req.getParameter("t3").toLowerCase());
		   e.setMobile(Long.parseLong(req.getParameter("t4")));
		   e.setCity(req.getParameter("t5").toLowerCase());
		   b=obj.employeeregister(e);
		   if(b)
		   {
			   RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			   rd.include(req, res);  
		   }
		   else
		   {
			   RequestDispatcher rd=req.getRequestDispatcher("signup.html");
			   rd.include(req, res); 
			   out.print("error");
		   }
		  
		 }
	  else if(path.equals("/reqempforget")) 
	    {
	    e.setName(req.getParameter("t1"));
	    e.setPwd(req.getParameter("t2"));
	    	boolean b=obj.forget(e);
	    	if(b)
	    	{
	    	 RequestDispatcher rd=req.getRequestDispatcher("signin.html");
	   		   rd.forward(req, res);
	    	}
	    	else
	    	{
	    		out.print(" Something went wrong");
	    	}
	   } 
      }
public void doGet(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
{ 
	  
	   PrintWriter out=res.getWriter();
    String path=req.getServletPath(); 
    Employee c=new Employee();
   
    if(path.equals("/reqempview"))
    {
    	 HttpSession session =req.getSession();
    	 String name=session.getAttribute("name").toString();
    
     c=obj.viewByuserId(name);
     out.print("<body bgcolor=CCFFFF><br><br><center><table border=3 cellpadding=10><tr><td>name</td><td>pwd</td><td>email</td><td>mobile</td><td>city</td><td>update</td></tr>");
 	out.print("<tr><td>"+c.getName()+"</td><td>"+c.getPwd()+"</td><td>"+c.getEmail()+"</td><td>"+c.getMobile()+"</td><td>"+c.getCity()+"</td><td><a href=reqempupdate?id="+c.getEmail()+">update</a></td></tr>");                                                                                                  
   
    out.print("</table><h1> Press  <a href=employehomepage.html><b>Menu</b></a>  to go back");
    }
    if(path.equals("/reqempdelete"))
    {
    	
    	
      String name=req.getParameter("id");
 	   boolean b=obj.delete1(name);
 	   if(b)
 	   {
 		   RequestDispatcher rd=req.getRequestDispatcher("reqviewallemployee");
				rd.forward(req, res);
 	   }
 	   else
 	   {
 		   
				out.print("error occured ");
 	   }
 	   
    }
    else if (path.equals("/reqempupdate"))
    { 
 	   String name=req.getParameter("id");
        c=obj.viewByuserId(name);
             
 	
 		 out.print("<body bgcolor=CCFFFF><br><br><center><form action=requpdate1><table border=3 cellpadding=10 ><tr><td>Name:</td><td><input type=text name=t1  value="+c.getName()+"></td></tr>");
 		 out.print("<tr><td>Pwd:   </td><td>     <input     type=text   name=t2  value="+c.getPwd()+"></td></tr>");
 	     out.print("<tr><td>Email: </td><td>     <input     type=text   name=t3 readonly  value="+c.getEmail()+"></td></tr>");
 	     out.print("<tr><td>Mobile:</td><td>     <input     type=text   name=t4  value="+c.getMobile()+"></td></tr>");
 	     out.print("<tr><td>City:  </td><td>     <input     type=text   name=t5  value="+c.getCity()+"></td></tr>");
 	     out.print("<tr><td><input type=submit value=Update></td><td><input type=reset value=reset></td></tr></table></form></body>");
 		
    }
    else if(path.equals("/requpdate1"))
    {  
 	   c.setName(req.getParameter("t1").toLowerCase());
 	   c.setPwd(req.getParameter("t2"));
 	   c.setEmail(req.getParameter("t3").toLowerCase());
 	   c.setMobile(Long.parseLong(req.getParameter("t4")));
 	   c.setCity(req.getParameter("t5").toLowerCase());
 	   boolean b=obj.update(c);
 	   if(b)
 	   {
 		   RequestDispatcher rd=req.getRequestDispatcher("reqempview");
 		   rd.forward(req, res);
 	   }
 	   else
 	   {RequestDispatcher rd=req.getRequestDispatcher("requpdate1");
 		   rd.forward(req, res);
 	   }
   }
    else if (path.equals("/reqviewallemployee"))
    {
    	ArrayList<Employee> al=new ArrayList<Employee>();
    	al=obj.viewallemployee();
    out.print("<body bgcolor=CCFFFF><br><br><center><table border=3 cellpadding=10><tr><td>name</td><td>email</td><td>mobile</td><td>city</td><td>update</td><td>delete</td></tr>");
	for(Employee c1:al) {
    out.print("<tr><td>"+c1.getName()+"</td><td>"+c1.getEmail()+"</td><td>"+c1.getMobile()+"</td><td>"+c1.getCity()+"</td><td><a href=reqempupdate1?id="+c1.getEmail()+">update</a></td><td><a href=reqempdelete?id="+c1.getEmail()+">delete</a></td></tr>");                                                                                                  
    } 
	
	 out.print("</table><h1> To go back press<a href=adminhomepage.html><b>Menu</a> ");
    
    }
    else if (path.equals("/reqempupdate1"))
    { 
 	   String name=req.getParameter("id");
        c=obj.viewByuserId(name);
             
 	
 		 out.print("<body bgcolor=CCFFFF><br><br><center><form action=requpdate12><table border=3 cellpadding=10 ><tr><td>Name:</td><td><input type=text name=t1  value="+c.getName()+"></td></tr>");
 		 out.print("<tr><td>Pwd:   </td><td>     <input     type=text   name=t2  value="+c.getPwd()+"></td></tr>");
 	     out.print("<tr><td>Email: </td><td>     <input     type=text   name=t3 readonly value="+c.getEmail()+"></td></tr>");
 	     out.print("<tr><td>Mobile:</td><td>     <input     type=text   name=t4  value="+c.getMobile()+"></td></tr>");
 	     out.print("<tr><td>City:  </td><td>     <input     type=text   name=t5  value="+c.getCity()+"></td></tr>");
 	     out.print("<tr><td><input type=submit value=Update></td><td><input type=reset value=reset></td></tr></table></form></body>");
 		
    }
    else if(path.equals("/requpdate12"))
    {  
 	   c.setName(req.getParameter("t1").toLowerCase());
 	   c.setPwd(req.getParameter("t2"));
 	   c.setEmail(req.getParameter("t3").toLowerCase());
 	   c.setMobile(Long.parseLong(req.getParameter("t4")));
 	   c.setCity(req.getParameter("t5").toLowerCase());
 	   boolean b=obj.update(c);
 	   if(b)
 	   {
 		   RequestDispatcher rd=req.getRequestDispatcher("reqviewallemployee");
 		   rd.forward(req, res);
 	   }
 	   else
 	   {RequestDispatcher rd=req.getRequestDispatcher("requpdate1");
 		   rd.forward(req, res);
 	   }
   }
    
    
	 
}
}

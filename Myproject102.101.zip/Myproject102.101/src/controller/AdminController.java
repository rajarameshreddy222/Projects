package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DaoImple;

import model.Admin;
import model.Customer;


@WebServlet(urlPatterns= {"/reqadminlogin"})
public class AdminController extends HttpServlet
{  DaoImple obj;
   
   Customer c=new Customer(); 
	public void init() throws ServletException
	{
		super.init();
		obj=new DaoImple();
	
	}
   public void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException, ServletException
   { PrintWriter out=res.getWriter();
	 String path=req.getServletPath();
	 
	 
	 if(path.equals("/reqlogin"))
	 {
		 
		 
		 
		 
		 
	 }

	 else if(path.equals("/reqadminlogin"))
	 {Admin a=new Admin();
	  boolean b=false;
		  a.setName(req.getParameter("t1"));
		  a.setPwd(req.getParameter("t2"));
		   b=obj.adminlogin(a);
		  if(b)
		  {
			RequestDispatcher rd=req.getRequestDispatcher("adminhomepage.html");
			rd.forward(req, res);
		  }
		  else
		  {
			  RequestDispatcher rd=req.getRequestDispatcher("signin.html");
				rd.include(req, res);
				out.print("error");
		  }	 
	 }
}}
